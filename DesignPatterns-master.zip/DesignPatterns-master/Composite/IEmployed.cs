﻿namespace Composite
{
    public interface IEmployed
    {
        int EmpID { get; set; }
        string Name { get; set; }
    }
}
