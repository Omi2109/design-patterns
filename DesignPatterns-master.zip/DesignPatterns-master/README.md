# DesignPatterns

All Design patterns are included in this solution
