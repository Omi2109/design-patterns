﻿using System;

namespace Facade
{
    public class CarAccessories
    {
        internal void SetAccessories()
        {
            Console.WriteLine("CarAccessories");
        }
    }
}
