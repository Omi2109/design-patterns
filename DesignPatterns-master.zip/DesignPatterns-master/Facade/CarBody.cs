﻿using System;

namespace Facade
{
    public class CarBody
    {
        internal void SetBody()
        {
            Console.WriteLine("CarBody");
        }
    }
}
