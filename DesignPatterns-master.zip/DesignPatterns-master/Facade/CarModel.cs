﻿using System;

namespace Facade
{
    public class CarModel
    {
        internal void SetModel()
        {
            Console.WriteLine("CarModel");
        }
    }
}
