﻿using System;

namespace Facade
{
    public class CarEngine
    {
        internal void SetEngine()
        {
            Console.WriteLine("CarEngine");
        }
    }
}
