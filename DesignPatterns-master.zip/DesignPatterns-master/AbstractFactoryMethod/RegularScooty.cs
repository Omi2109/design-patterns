﻿namespace AbstractFactoryMethod
{
    internal class RegularScooty : IScooter
    {
        public string Name()
        {
            return "RegularScooty";
        }
    }
}