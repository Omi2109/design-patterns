﻿namespace AbstractFactoryMethod
{
    internal class RegularBike : IBike
    {
        public string Name()
        {
            return "Regular Bike";
        }
    }
}