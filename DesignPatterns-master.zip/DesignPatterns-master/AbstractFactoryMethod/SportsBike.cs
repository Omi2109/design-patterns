﻿namespace AbstractFactoryMethod
{
    internal class SportsBike : IBike
    {
        public string Name()
        {
            return "Sports Bike";
        }
    }
}