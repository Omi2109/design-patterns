﻿namespace AbstractFactoryMethod
{
    public interface IBike
    {
        string Name();
    }
}
