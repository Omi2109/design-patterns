﻿namespace AbstractFactoryMethod
{
    public interface IScooter
    {
        string Name();
    }
}
