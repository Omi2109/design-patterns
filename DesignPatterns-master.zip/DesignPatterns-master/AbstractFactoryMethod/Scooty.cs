﻿namespace AbstractFactoryMethod
{
    internal class Scooty : IScooter
    {
        public string Name()
        {
            return "Scooty";
        }
    }
}