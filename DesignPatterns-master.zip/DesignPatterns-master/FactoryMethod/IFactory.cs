﻿namespace FactoryMethod
{
    public interface IFactory
    {
        void Drive(int miles);
    }
}
