﻿using System;

namespace Command
{
    public class Light
    {
        public void TurnOn()
        {
            Console.WriteLine("Light is turn on");
        }

        public void TurnOff()
        {
            Console.WriteLine("Light is turn off");
        }
    }
}
