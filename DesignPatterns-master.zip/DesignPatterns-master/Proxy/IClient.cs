﻿namespace Proxy
{
    internal interface IClient
    {
        string GetData();
    }
}