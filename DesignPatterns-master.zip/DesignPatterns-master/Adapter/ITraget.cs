﻿using System.Collections.Generic;

namespace Adapter
{
    public interface ITraget
    {
        List<string> GetEmployeeList();
    }
}
