﻿namespace Strategy
{
    public interface INetPayable
    {
        double CalculateTotal();
    }
}
